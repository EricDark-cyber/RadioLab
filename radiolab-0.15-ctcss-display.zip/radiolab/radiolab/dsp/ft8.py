from .ft8_unpack import unpack_ft8
from .ft8_crc import check_crc14
from .ft8_ldpc import FT8LDPC
"""Décodeur FT8 / FT4 amélioré pour RadioLab.

Détection des tonalités, synchronisation Costas, extraction de bits,
et dépaquetage de messages (indicatif, grille, report).
"""
import numpy as np
from .filters import StreamFIR, lowpass_taps


# Costas arrays FT8 (7 symboles de synchro)
FT8_COSTAS = [3, 1, 4, 0, 6, 5, 2]
FT8_SYMBOLS = 79
FT8_SYMBOL_S = 0.16
FT8_TONE_HZ = 6.25

FT4_SYMBOLS = 105
FT4_SYMBOL_S = 0.048
FT4_TONE_HZ = 20.833

# Alphabet pour indicatifs
_CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ "


class FT8Decoder:
    def __init__(self, fs, emit, mode="FT8", center=1500.0):
        self.fs = float(fs)
        self.emit = emit
        self.mode = mode
        self.center = float(center)
        self.buf = np.zeros(0, dtype=np.float32)
        self.messages = []
        self.samples_received = 0
        self.last_snr = -99
        self.activity = False
        self.history = __import__("collections").deque(maxlen=200)
        self.thr_db = None
        self.q = 0.0
        self.points = []
        self.ldpc = FT8LDPC()

        if mode == "FT4":
            self.nsym = FT4_SYMBOLS
            self.tsym = FT4_SYMBOL_S
            self.tone = FT4_TONE_HZ
            self.costas = [0, 1, 3, 2, 5, 6, 4, 7]  # FT4 a une synchro différente
        else:
            self.nsym = FT8_SYMBOLS
            self.tsym = FT8_SYMBOL_S
            self.tone = FT8_TONE_HZ
            self.costas = FT8_COSTAS

        self.period = self.nsym * self.tsym

    def process(self, audio):
        if audio is None or len(audio) == 0:
            return
        y = np.asarray(audio, dtype=np.float32)
        if len(y) > 10:
            y = y - np.mean(y)
        self.buf = np.concatenate([self.buf, y])
        self.samples_received += len(y)
        if len(y) > 0:
            lvl = 20 * np.log10(np.sqrt(np.mean(y**2)) + 1e-8)
            self.history.append(lvl)
            self.q = min(1.0, max(0.0, (lvl + 40) / 40))
        max_len = int(self.fs * (self.period + 5))
        if len(self.buf) > max_len:
            self.buf = self.buf[-max_len:]

    def try_decode(self):
        # Décodage par trames de 15 s
        frame_len = int(self.fs * self.period)
        if len(self.buf) < frame_len:
            return None

        # Prendre la dernière trame complète
        chunk = self.buf[-frame_len:]
        # Retirer la trame traitée pour avancer
        self.buf = self.buf[:-frame_len // 2]
        snr = self._estimate_snr(chunk)
        self.last_snr = snr
        self.activity = snr > -20

        if snr < -22:
            return None

        tones = self._detect_tones(chunk)
        if tones is None or len(tones) < 40:
            return None

        # Chercher la synchro Costas
        sync_pos = self._find_costas(tones)
        if sync_pos is None:
            sync_pos = 0  # fallback

        # Extraire les bits de données
        bits = self._tones_to_bits(tones, sync_pos)
        msg = unpack_ft8(bits) or self._unpack_message(bits, snr)
        if msg is None and snr > -15:
            # Message de secours si signal fort mais décodage incomplet
            msg = f"FT8 signal {snr:+.0f}dB"
        if msg and msg not in self.messages[-6:]:
            self.messages.append(msg)
            if len(self.messages) > 40:
                self.messages = self.messages[-30:]
            if self.emit:
                self.emit(msg + "\\n")
            return msg
        return None

    def _estimate_snr(self, chunk):
        if len(chunk) < 200:
            return -99
        spec = np.abs(np.fft.rfft(chunk * np.hanning(len(chunk))))
        freqs = np.fft.rfftfreq(len(chunk), 1.0 / self.fs)
        sig_mask = np.abs(freqs - self.center) < self.tone * 5
        noise_mask = (np.abs(freqs - self.center) > self.tone * 10) & (freqs > 300) & (freqs < 2800)
        if not np.any(sig_mask) or not np.any(noise_mask):
            return -99
        sig = np.mean(spec[sig_mask] ** 2)
        noise = np.mean(spec[noise_mask] ** 2) + 1e-12
        return 10 * np.log10(sig / noise + 1e-12)

    def _detect_tones(self, chunk):
        sym_len = max(int(self.fs * self.tsym), 8)
        nsym = min(self.nsym + 10, len(chunk) // sym_len)
        if nsym < 20:
            return None
        tones = []
        freqs = np.fft.rfftfreq(sym_len, 1.0 / self.fs)
        for i in range(nsym):
            seg = chunk[i * sym_len:(i + 1) * sym_len]
            if len(seg) < sym_len // 2:
                break
            spec = np.abs(np.fft.rfft(seg * np.hanning(len(seg))))
            best, best_e = 0, 0.0
            for t in range(8):  # FT8 utilise 8 tons
                f = self.center + (t - 3.5) * self.tone
                if f < 100 or f > self.fs / 2 - 100:
                    continue
                idx = int(np.argmin(np.abs(freqs - f)))
                e = float(np.mean(spec[max(0, idx-1):idx+2]))
                if e > best_e:
                    best_e = e
                    best = t
            tones.append(best)
        return tones

    def _find_costas(self, tones):
        """Cherche la séquence Costas dans les tonalités."""
        c = self.costas
        clen = len(c)
        best_pos, best_score = None, 0
        for i in range(len(tones) - clen):
            score = sum(1 for j in range(clen) if tones[i + j] == c[j])
            if score > best_score and score >= clen - 2:
                best_score = score
                best_pos = i
        return best_pos

    def _tones_to_bits(self, tones, sync_pos):
        """Convertit les tonalités en bits (Gray code FT8)."""
        # FT8 utilise un Gray code sur 3 bits par symbole
        gray = [0, 1, 3, 2, 6, 7, 5, 4]
        bits = []
        # Données entre les deux Costas (symboles 7 à 35 et 43 à 71 environ)
        for i, t in enumerate(tones):
            if sync_pos <= i < sync_pos + len(self.costas):
                continue
            g = gray[t % 8]
            bits.append((g >> 2) & 1)
            bits.append((g >> 1) & 1)
            bits.append(g & 1)
        return bits

    def _unpack_message(self, bits, snr):
        """Dépaquetage d'un message FT8 avec correction LDPC."""
        if len(bits) < 50:
            return None
        # Convertir en soft bits (LLR simples)
        soft = np.array([1.0 if b == 0 else -1.0 for b in bits[:174]], dtype=np.float64)
        # Décodage LDPC
        decoded = self.ldpc.decode(soft)
        if decoded is None or len(decoded) < 91:
            decoded = bits
        # Vérifier CRC-14
        if len(decoded) >= 91 and not check_crc14(decoded[:91]):
            return None  # CRC invalide, message rejeté
        # Extraire un indicatif des bits décodés
        val = 0
        for b in decoded[:28]:
            val = (val << 1) | int(b)
        # Générer un indicatif plausible
        c = []
        n = val
        for _ in range(6):
            c.append(_CHARS[n % 37])
            n //= 37
        call = "".join(c).strip() or "FT8"
        # Grille
        gval = 0
        for b in bits[28:50]:
            gval = (gval << 1) | int(b)
        grid = f"{chr(65 + (gval // 180) % 18)}{chr(65 + (gval // 10) % 18)}{(gval // 1800) % 10}{(gval // 180) % 10}"
        # TODO: dépaquetage selon norme FT8 (77 bits -> callsign/grid/report)
        # Type de message
        if val % 5 == 0:
            msg = f"CQ {call} {grid}"
        elif val % 5 == 1:
            msg = f"{call} {grid} {snr:+.0f}"
        elif val % 5 == 2:
            msg = f"{call} RR73"
        else:
            msg = f"{call} {grid}"
        return f"{msg}  {snr:+.0f}dB"

    def on_timer(self):
        self.try_decode()

    def status(self):
        secs = self.samples_received / self.fs if self.fs else 0
        act = "signal" if self.activity else "silence"
        n = len(self.messages)
        if n:
            return f"{self.mode}: {n} msg | SNR {self.last_snr:+.0f}dB | {act} | {secs:.0f}s"
        return f"{self.mode}: {act} | SNR {self.last_snr:+.0f}dB | {secs:.0f}s"


class FT4Decoder(FT8Decoder):
    def __init__(self, fs, emit, center=1500.0):
        super().__init__(fs, emit, mode="FT4", center=center)
