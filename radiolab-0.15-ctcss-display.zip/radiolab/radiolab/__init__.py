"""RadioLab : récepteur SDR de bureau en Python pour Airspy R2 (+ SpyVerter)."""
__version__ = "0.15.0"
